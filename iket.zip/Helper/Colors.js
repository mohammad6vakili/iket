const Colors = {
    purple:"#5925B6",
    gray:"rgb(117, 117, 117)",
    success:"#00a854"
}
export default Colors;